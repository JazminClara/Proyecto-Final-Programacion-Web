package com.dimensionrug.presupuestar.models.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name = "pegamentos")
public class Pegamento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pegamento", nullable = false)
    private Integer idPegamento;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(name = "precio_kilo", nullable = false)
    private Double precioKilo;

    @Column(name = "consumo_m2", nullable = false)
    private Double consumoM2;

    @Column(name = "precio_m2")
    private Double precioM2;

    /* @OneToMany(mappedBy = "pegamento")
    @JsonBackReference
    private List<Presupuesto> presupuestos; */

    @PrePersist
    @PreUpdate
    private void calcularprecioM2() {
        this.precioM2 = consumoM2 * precioKilo;
    }

    public Double getPrecioM2(){
        if (precioM2 == null) {
            this.calcularprecioM2();
        }
        return precioM2;
    }
}