package com.dimensionrug.presupuestar.controllers;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dimensionrug.presupuestar.models.entities.Tela;
import com.dimensionrug.presupuestar.models.enums.Uso;
import com.dimensionrug.presupuestar.services.TelaService;

@Controller
public class TelaController {
    private final TelaService telaService;

    public TelaController(TelaService telaService) {
        this.telaService = telaService;
    }

    @GetMapping("/telas")
    public String listarTelas(Model model) {
        try {
            List<Tela> telas = telaService.getTelas();
            model.addAttribute("telas", telas);
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorTablas", "Error en cargar tablas de Telas" + e.getMessage());
        }
        return "telas-lista";
    }

    @GetMapping("/tela/alta")
    public String altaTelaForm(Model model) {
        model.addAttribute("tela", new Tela());
        model.addAttribute("uso", Arrays.asList(Uso.values()));
        return "tela-alta";
    }

    @PostMapping("/tela/guardar")
    public String guardarTela(@ModelAttribute("tela") Tela tela, Model model) {
        try {
            telaService.saveTela(tela);;
            return "redirect:/telas";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorGuardar", "Error al guardar el tela" + e.getMessage());
            model.addAttribute("uso", Arrays.asList(Uso.values()));
            return "tela-alta";
        }
    }

    @GetMapping("/tela/editar")
    public String editarTelas(@RequestParam("id") int id, Model model) {
        try {
            Tela tela = telaService.findTela(id);
            if (tela != null) {
                model.addAttribute("tela", tela);
                model.addAttribute("usos", Arrays.asList(Uso.values()));
                return "tela-editar";
            } else {
                return "redirect:/telas";
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorId", "Error al buscar id de la tela para editar" + e.getMessage());
            return "telas-lista";
        }
    }

    @PostMapping("tela/actualizar")
    public String actualizarTela(@ModelAttribute("tela") Tela tela, Model model) {
        try {
            telaService.editTela(tela.getIdTela(), tela.getNombre(), tela.getUso(), tela.getAnchoFabrica(), tela.getPrecioMetro());;
            return "redirect:/telas";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorGuardar", "Eror al guardar la tela" + e.getMessage());
            model.addAttribute("tela", tela);
            model.addAttribute("usos", Arrays.asList(Uso.values()));
            return "tela-editar";
        }
    }

    @GetMapping("/tela/eliminar")
    public String eliminarTela(@RequestParam("id") int id, Model model) {
        try {
            telaService.deletePersona(id);;
            return "redirect:/telas";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorEliminar", "Error al eliminar la tela" + e.getMessage());
            try {
                model.addAttribute("telas", telaService.getTelas());
            } catch (Exception ex) {
                ex.printStackTrace();
                model.addAttribute("errorTablasAlEliminar", "Error al cargar telas luego de eliminación fallida" + ex.getMessage());
            }
            return "telas-lista";
        } 

    }
}
