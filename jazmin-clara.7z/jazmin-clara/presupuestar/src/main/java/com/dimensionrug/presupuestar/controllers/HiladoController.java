package com.dimensionrug.presupuestar.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dimensionrug.presupuestar.models.entities.Hilado;
import com.dimensionrug.presupuestar.services.HiladoService;

@Controller
public class HiladoController {
    private HiladoService hiladoService;

    public HiladoController(HiladoService hiladoService) {
        this.hiladoService = hiladoService;
    }

    @GetMapping("/hilados")
    public String listarHilados(Model model) {
        try {
            List<Hilado> hilados = hiladoService.getHilados();
            model.addAttribute("hilados", hilados);
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorTablas", "Error en cargar tablas de Hilados" + e.getMessage());
        }
        return "hilados-lista";
    }

    @GetMapping("/hilado/alta")
    public String altaHiladoForm(Model model) {
        model.addAttribute("hilado", new Hilado());
        return "hilado-alta";
    }

    @PostMapping("/hilado/guardar")
    public String guardarHilado(@ModelAttribute("hilado") Hilado hilado, Model model) {
        try {
            hiladoService.saveHilado(hilado);;
            return "redirect:/hilados";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorGuardar", "Error al guardar el hilado" + e.getMessage());
            return "hilado-alta";
        }
    }

    @GetMapping("/hilado/editar")
    public String editarHilados(@RequestParam("id") int id, Model model) {
        try {
            Hilado hilado = hiladoService.findHilado(id);
            if (hilado != null) {
                model.addAttribute("hilado", hilado);
                return "hilado-editar";
            } else {
                return "redirect:/hilados";
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorId", "Error al buscar id del hilado para editar" + e.getMessage());
            return "hilados-lista";
        }
    }

    @PostMapping("hilado/actualizar")
    public String actualizarHilado(@ModelAttribute("hilado") Hilado hilado, Model model) {
        try {
            hiladoService.editHilado(hilado.getIdHilado(), hilado.getNombre(), hilado.getColor(), hilado.getPrecioKilo(), hilado.getConsumoM2());;
            return "redirect:/hilados";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorGuardar", "Eror al guardar la hilado" + e.getMessage());
            model.addAttribute("hilado", hilado);
            return "hilado-editar";
        } 
    }

    @GetMapping("/hilado/eliminar")
    public String eliminarHilado(@RequestParam("id") int id, Model model) {
        try {
            hiladoService.deleteHilado(id);
            return "redirect:/hilados";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorEliminar", "Error al eliminar la hilado" + e.getMessage());
            try {
                model.addAttribute("hilados", hiladoService.getHilados());
            } catch (Exception ex) {
                ex.printStackTrace();
                model.addAttribute("errorTablasAlEliminar", "Error al cargar hilados luego de eliminación fallida" + ex.getMessage());
            }
            return "hilados-lista";
        } 

    }
}
