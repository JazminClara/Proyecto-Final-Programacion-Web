package com.dimensionrug.presupuestar.services;

import java.util.List;

import com.dimensionrug.presupuestar.models.entities.Tela;
import com.dimensionrug.presupuestar.models.enums.Uso;

public interface ITelaService {
    public List<Tela> getTelas();
    
    public void saveTela(Tela tela);

    public void deletePersona(Integer id);

    public Tela findTela(Integer id);

    public void editTela(Integer id, String nombre, Uso uso, Double anchoFabrica, Double precioMetro);
}