package com.dimensionrug.presupuestar.services;

import java.util.List;

import com.dimensionrug.presupuestar.models.entities.Presupuesto;


public interface IPresupuestoService {
    public List<Presupuesto> getPresupuestos();

    public void savePresupuesto(Presupuesto presupuesto);

    public void deletePresupuesto(Integer id);

    public Presupuesto findPresupuesto(Integer id);

    public void editPresupuesto(Integer id, String nombreCliente, Double anchoAlfombra, Double largoAlfombra,
            Integer idTelaBase, Integer idTelaFondo, Integer idHilado, Integer idPegamento);

    public List<Presupuesto> findByNombreClienteContaining(String nombreCliente);

    public List<Presupuesto> findByPrecioTotalBetween(Double precioMinimo, Double precioMaximo);
}