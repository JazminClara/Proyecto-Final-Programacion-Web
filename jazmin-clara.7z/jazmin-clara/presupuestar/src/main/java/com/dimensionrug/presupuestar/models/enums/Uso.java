package com.dimensionrug.presupuestar.models.enums;

public enum Uso {
    BASE, FONDO;
}
