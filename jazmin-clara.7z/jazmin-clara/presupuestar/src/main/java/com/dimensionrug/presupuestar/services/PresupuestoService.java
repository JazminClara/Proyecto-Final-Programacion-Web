package com.dimensionrug.presupuestar.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dimensionrug.presupuestar.models.entities.Presupuesto;
import com.dimensionrug.presupuestar.models.repositories.interfaces.IPresupuestoRepository;

@Service
public class PresupuestoService implements IPresupuestoService {
    @Autowired
    private IPresupuestoRepository presupuestoRepository;

    @Autowired
    private ITelaService telaService;

    @Autowired
    private IPegamentoService pegamentoService;

    @Autowired
    private IHiladoService hiladoService;

    @Override
    public List<Presupuesto> getPresupuestos() {
        List<Presupuesto> listaPresupuestos = presupuestoRepository.findAll();
        return listaPresupuestos;
    }

    @Override
    public void savePresupuesto(Presupuesto presupuesto) {
        if (presupuesto != null) {

            // Realizo validación de regla de negocio
            this.validarCantidadPresupuestos(presupuesto);

            // Calculo el presupuesto total
            this.presupuestar(presupuesto);

            // Realizo segunda validación: descuento superando determinado monto
            this.descontarSuperandoMinimo(presupuesto);

            // Luego de las reglas de negocio y el cálculo de presupuestar se persiste
            presupuestoRepository.save(presupuesto);
        }
    }

    @Override
    public void deletePresupuesto(Integer id) {
        if (id != null)
            presupuestoRepository.deleteById(id);
    }

    @Override
    public Presupuesto findPresupuesto(Integer id) {
        Presupuesto presupuesto = null;
        if (id != null)
            presupuesto = presupuestoRepository.findById(id).orElse(null);
        return presupuesto;
    }

    @Override
    public void editPresupuesto(Integer id, String nombreCliente, Double anchoAlfombra, Double largoAlfombra,
            Integer idTelaBase, Integer idTelaFondo, Integer idHilado, Integer idPegamento) {
        Presupuesto presupuesto = this.findPresupuesto(id);

        presupuesto.setNombreCliente(nombreCliente);
        presupuesto.setAnchoAlfombra(anchoAlfombra);
        presupuesto.setLargoAlfombra(largoAlfombra);
        presupuesto.setTelaBase(telaService.findTela(idTelaBase));
        presupuesto.setTelaFondo(telaService.findTela(idTelaFondo));
        presupuesto.setHilado(hiladoService.findHilado(idHilado));
        presupuesto.setPegamento(pegamentoService.findPegamento(idPegamento));

        this.savePresupuesto(presupuesto);
    }

    // Hacer filtros en la vista!!
    @Override
    public List<Presupuesto> findByNombreClienteContaining(String nombreCliente) {
        List<Presupuesto> listaPresupuestos = presupuestoRepository.findByNombreClienteContaining(nombreCliente);
        return listaPresupuestos;
    }

    @Override
    public List<Presupuesto> findByPrecioTotalBetween(Double precioMinimo, Double precioMaximo) {
        List<Presupuesto> listaPresupuestos = presupuestoRepository.findByPrecioTotalBetween(precioMinimo,
                precioMaximo);
        return listaPresupuestos;
    }

    /* Métodos que me permiten calcular el precio final del presupuesto */
    private Double calcularTelaBase(Presupuesto presupuesto) {
        Double precioM2Tela = presupuesto.getTelaBase().getPrecioM2();
        return precioM2Tela * presupuesto.getAlfombraM2();
    }

    private Double calcularTelaFondo(Presupuesto presupuesto) {
        Double precioM2Tela = presupuesto.getTelaFondo().getPrecioM2();
        return precioM2Tela * presupuesto.getAlfombraM2();
    }

    private Double calcularHilado(Presupuesto presupuesto) {
        Double precioM2Hilado = presupuesto.getHilado().getPrecioM2();
        return precioM2Hilado * presupuesto.getAlfombraM2();
    }

    private Double calcularPegamento(Presupuesto presupuesto) {
        Double precioM2Pegamento = presupuesto.getPegamento().getPrecioM2();
        return precioM2Pegamento * presupuesto.getAlfombraM2();
    }

    public void presupuestar(Presupuesto presupuesto) {
        Double precioTotal = calcularTelaBase(presupuesto) + calcularTelaFondo(presupuesto) +
                calcularHilado(presupuesto) + calcularPegamento(presupuesto);
        presupuesto.setPrecioTotal(precioTotal);
        presupuestoRepository.save(presupuesto);
    }

    // Reglas de negocio
    private void validarCantidadPresupuestos(Presupuesto presupuesto) {

        // Reutilizo query methods para crear una lista con presupuestos que tenga el
        // mismo nombre
        List<Presupuesto> presupuestosConMismoNombre = presupuestoRepository
                .findByNombreClienteIgnoreCase(presupuesto.getNombreCliente());

        // Validación de hasta 3 presupuestos realizados
        if (presupuestosConMismoNombre.size() > 3) {
            throw new IllegalArgumentException(
                    "El cliente " + presupuesto.getNombreCliente()
                            + " ya tiene 3 presupuestos realizados");
        }
    }

    private void descontarSuperandoMinimo(Presupuesto presupuesto) {
        // Descuento del 10% en presupuestos igual o superiores a 500000
        if (presupuesto.getPrecioTotal() >= 500000) {
            double totalConDescuento = presupuesto.getPrecioTotal() * 0.90;
            presupuesto.setPrecioTotal(totalConDescuento);
        }
    }
}