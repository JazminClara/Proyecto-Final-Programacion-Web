package com.dimensionrug.presupuestar.services;

import java.util.List;

import com.dimensionrug.presupuestar.models.entities.Hilado;

public interface IHiladoService {
    public List<Hilado> getHilados();

    public void saveHilado(Hilado hilado);

    public void deleteHilado(Integer id);

    public Hilado findHilado(Integer id);

    public void editHilado(Integer id, String nombre, String color, Double precioKilo, Double consumoM2);
    
}