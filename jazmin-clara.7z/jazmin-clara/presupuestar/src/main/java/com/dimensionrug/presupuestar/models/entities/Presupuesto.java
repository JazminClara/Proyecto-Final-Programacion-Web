package com.dimensionrug.presupuestar.models.entities;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "presupuestos")
public class Presupuesto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_presupuesto", nullable = false)
    private Integer idPresupuesto;

    @Column(name = "nombre_cliente", nullable = false)
    private String nombreCliente;

    @Column(name = "ancho_alfombra", nullable = false)
    private Double anchoAlfombra;

    @Column(name = "largo_alfombra", nullable = false)
    private Double largoAlfombra;
    
    @Transient
    private Double alfombraM2;

    @Column(name = "precio_total")
    private Double precioTotal;

    @ToString.Exclude
    @ManyToOne
    @JsonManagedReference
    @JoinColumn(name = "id_tela_base", nullable = false)
    private Tela telaBase;
    
    @ToString.Exclude
    @ManyToOne()
    @JsonManagedReference
    @JoinColumn(name = "id_tela_fondo", nullable = false)
    private Tela telaFondo;

    @ToString.Exclude
    @ManyToOne
    @JsonManagedReference
    @JoinColumn(name = "id_hilado", nullable = false)
    private Hilado hilado;

    @ToString.Exclude
    @ManyToOne
    @JsonManagedReference
    @JoinColumn(name = "id_pegamento", nullable = false)
    private Pegamento pegamento;

    
    public Double getAlfombraM2() {
        if (alfombraM2 == null) {
            this.alfombraM2 = anchoAlfombra * largoAlfombra;
        }
        return alfombraM2;
    };
}