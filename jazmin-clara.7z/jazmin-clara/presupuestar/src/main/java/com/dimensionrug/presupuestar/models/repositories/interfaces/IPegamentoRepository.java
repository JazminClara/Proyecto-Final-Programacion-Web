package com.dimensionrug.presupuestar.models.repositories.interfaces;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.dimensionrug.presupuestar.models.entities.Pegamento;

@Repository
public interface IPegamentoRepository extends JpaRepository<Pegamento,Integer>{
    
}
