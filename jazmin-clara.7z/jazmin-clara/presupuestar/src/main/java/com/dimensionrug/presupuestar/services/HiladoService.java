package com.dimensionrug.presupuestar.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dimensionrug.presupuestar.models.entities.Hilado;
import com.dimensionrug.presupuestar.models.repositories.interfaces.IHiladoRepository;

@Service
public class HiladoService implements IHiladoService {
    @Autowired
    private IHiladoRepository hiladoRepository;

    @Override
    public List<Hilado> getHilados() {
        List<Hilado> listaHilados = hiladoRepository.findAll();
        return listaHilados;
    }

    @Override
    public void saveHilado(Hilado hilado) {
        if (hilado != null) hiladoRepository.save(hilado);
    }

    @Override
    public void deleteHilado(Integer id) {
        if (id != null) hiladoRepository.deleteById(id);
    }

    @Override
    public Hilado findHilado(Integer id) {
        Hilado hilado = null;
        if (id != null)  hilado = hiladoRepository.findById(id).orElse(null);
        return hilado;
    }

    @Override
    public void editHilado(Integer id, String nombre, String color, Double precioKilo, Double consumoM2) {
        Hilado hilado = this.findHilado(id);

        hilado.setNombre(nombre);
        hilado.setColor(color);
        hilado.setPrecioKilo(precioKilo);
        hilado.setConsumoM2(consumoM2);

        this.saveHilado(hilado);
    }
}