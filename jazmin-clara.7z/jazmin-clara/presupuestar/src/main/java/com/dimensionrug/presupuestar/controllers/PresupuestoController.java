package com.dimensionrug.presupuestar.controllers;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dimensionrug.presupuestar.models.entities.Hilado;
import com.dimensionrug.presupuestar.models.entities.Pegamento;
import com.dimensionrug.presupuestar.models.entities.Presupuesto;
import com.dimensionrug.presupuestar.models.entities.Tela;
import com.dimensionrug.presupuestar.services.HiladoService;
import com.dimensionrug.presupuestar.services.PegamentoService;
import com.dimensionrug.presupuestar.services.PresupuestoService;
import com.dimensionrug.presupuestar.services.TelaService;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/presupuestos")
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class PresupuestoController {
    private final HiladoService hiladoService;
    private final PegamentoService pegamentoService;
    private final PresupuestoService presupuestoService;
    private final TelaService telaService;

    public PresupuestoController(HiladoService hiladoService, PegamentoService pegamentoService,
            PresupuestoService presupuestoService, TelaService telaService) {
        this.hiladoService = hiladoService;
        this.pegamentoService = pegamentoService;
        this.presupuestoService = presupuestoService;
        this.telaService = telaService;
    }

    @GetMapping
    @ResponseBody
    public ResponseEntity<List<Presupuesto>> obtenerPresupuestos(@RequestParam(required = false) String nombreCliente,
            @RequestParam(required = false) Double precioMinimo,
            @RequestParam(required = false) Double precioMaximo) {
        try {
            List<Presupuesto> listaPresupuestos = null;

            // If en cadena que llama a distintos métodos según que argumentos fueron
            // enviados en el RequestParam
            if (nombreCliente != null) {
                listaPresupuestos = presupuestoService.findByNombreClienteContaining(nombreCliente);
            } else if (precioMinimo != null && precioMaximo != null) {
                listaPresupuestos = presupuestoService.findByPrecioTotalBetween(precioMinimo,
                        precioMaximo);
            } else {
                listaPresupuestos = presupuestoService.getPresupuestos();
                listaPresupuestos.forEach(i -> presupuestoService.presupuestar(i));
            }

            if (listaPresupuestos.isEmpty()) {
                // Respuesta 204 en caso de que la lista esté vacía
                return ResponseEntity.noContent().build();
            }

            // Si esta la lista con los objetos envía respuesta de ok
            return ResponseEntity.ok(listaPresupuestos);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/alta")
    public String altaPresupuestoForm(Model model) {
        model.addAttribute("presupuesto", new Presupuesto());
        try {
            List<Tela> telas = telaService.getTelas();
            model.addAttribute("telas", telas);
            List<Hilado> hilados = hiladoService.getHilados();
            model.addAttribute("hilados", hilados);
            List<Pegamento> pegamentos = pegamentoService.getPegamentos();
            model.addAttribute("pegamentos", pegamentos);
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorTablas", "Error al cargar tablas" + e.getMessage());
        }
        return "presupuesto-alta";
    }

    @PostMapping("/guardar")
    public String guardarPresupuesto(@ModelAttribute("presupuesto") Presupuesto presupuesto, Model model) {
        try {
            presupuestoService.savePresupuesto(presupuesto);
            return "redirect:/";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorForm", "Error al guardar el presupuesto" + e.getMessage());
            try {
                model.addAttribute("telas", telaService.getTelas());
                model.addAttribute("hilados", hiladoService.getHilados());
                model.addAttribute("pegamentos", pegamentoService.getPegamentos());
            } catch (Exception ex) {
                ex.printStackTrace();
                model.addAttribute("errorForm2",
                        "Error al listado presupuesto luego de un guardado fallido" + e.getMessage());
            }
            return "presupuesto-alta";
        }
    }

    @GetMapping("/editar")
    public String editarPresupuesto(@RequestParam("id") int id, Model model) {
        try {
            Presupuesto presupuesto = presupuestoService.findPresupuesto(id);
            if (presupuesto != null) {
                model.addAttribute("presupuesto", presupuesto);
                List<Tela> telas = telaService.getTelas();
                model.addAttribute("telas", telas);
                List<Hilado> hilados = hiladoService.getHilados();
                model.addAttribute("hilados", hilados);
                List<Pegamento> pegamentos = pegamentoService.getPegamentos();
                model.addAttribute("pegamentos", pegamentos);
                return "presupuesto-editar";
            } else {
                return "redirect:/";
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorEditarPresupuesto", "Error al cargar presupuesto para editar" + e.getMessage());
            return "redirect:/";
        }
    }

    @PostMapping("/actualizar")
    public String actualizarPresupuesto(@ModelAttribute("presupuesto") Presupuesto presupuesto, Model model) {
        try {
            presupuestoService.editPresupuesto(presupuesto.getIdPresupuesto(), presupuesto.getNombreCliente(),
                    presupuesto.getAnchoAlfombra(), presupuesto.getLargoAlfombra(),
                    /*
                     * Desde la vista vienen los objetos (telas, hilado, pegamento) con nulls
                     * excepto el id
                     * Obtengo solo el id de lo que ingresó en el form
                     */
                    presupuesto.getTelaBase().getIdTela(),
                    presupuesto.getTelaFondo().getIdTela(),
                    presupuesto.getHilado().getIdHilado(),
                    presupuesto.getPegamento().getIdPegamento());
            return "redirect:/";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorActualizarPresupuesto",
                    "Error al actualizar datos del presupuesto" + e.getMessage());
            try {
                model.addAttribute("telas", telaService.getTelas());
                model.addAttribute("hilados", hiladoService.getHilados());
                model.addAttribute("pegamentos", pegamentoService.getPegamentos());
            } catch (Exception ex) {
                ex.printStackTrace();
                model.addAttribute("errorTablas", "Error al cargar tablas" + e.getMessage());
            }
            return "presupuesto-editar";
        }
    }

    @DeleteMapping("/{id}")
    @ResponseBody
    public ResponseEntity<String> eliminarPresupuesto(@PathVariable Integer id) {
        try {
            presupuestoService.deletePresupuesto(id);
            return ResponseEntity.ok("Presupuesto eliminado correctamente");
        } catch (NoSuchElementException | EmptyResultDataAccessException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontro el presupuesto: " + id);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error interno");
        }
    }
}