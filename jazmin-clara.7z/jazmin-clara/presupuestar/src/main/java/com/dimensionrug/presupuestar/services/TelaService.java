package com.dimensionrug.presupuestar.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dimensionrug.presupuestar.models.entities.Tela;
import com.dimensionrug.presupuestar.models.enums.Uso;
import com.dimensionrug.presupuestar.models.repositories.interfaces.ITelaRepository;

@Service
public class TelaService implements ITelaService {
    @Autowired
    private ITelaRepository telaRepository;

    @Override
    public List<Tela> getTelas() {
        List<Tela> listaTelas = telaRepository.findAll();
        return listaTelas;
    }

    @Override
    public void saveTela(Tela tela) {
        if (tela != null) telaRepository.save(tela);
    }

    @Override
    public void deletePersona(Integer id) {
        if (id != null) telaRepository.deleteById(id);
    }

    @Override
    public Tela findTela(Integer id) {
        Tela tela = null;
        if (id != null) tela = telaRepository.findById(id).orElse(null);
        return tela;
    }

    @Override
    public void editTela(Integer id, String nombre, Uso uso, Double anchoFabrica, Double precioMetro) {
        Tela tela = this.findTela(id);

        tela.setNombre(nombre);
        tela.setUso(uso);
        tela.setAnchoFabrica(anchoFabrica);
        tela.setPrecioMetro(precioMetro);

        this.saveTela(tela);
    }
}
