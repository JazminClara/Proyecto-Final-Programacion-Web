package com.dimensionrug.presupuestar.models.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Entity
@Data
@NoArgsConstructor
@Table(name = "hilados")
public class Hilado {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_hilado", nullable = false)
    private Integer idHilado;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(name = "color")
    private String color;

    @Column(name = "precio_kilo", nullable = false)
    private Double precioKilo;

    @Column(name = "consumo_m2", nullable = false)
    private Double consumoM2;
    
    private Double precioM2;

    /* @OneToMany(mappedBy = "hilado")
    @JsonBackReference
    private List<Presupuesto> presupuestos; */

    @PrePersist
    @PreUpdate
    private void calcularPrecioM2() {
        this.precioM2 = consumoM2 * precioKilo;
    }

    public Double getPrecioM2() {
        if (precioM2 == null) {
            this.calcularPrecioM2();
        }
        return precioM2;
    }    
}