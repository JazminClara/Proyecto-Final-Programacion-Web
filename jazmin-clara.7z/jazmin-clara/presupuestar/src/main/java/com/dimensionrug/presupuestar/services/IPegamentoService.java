package com.dimensionrug.presupuestar.services;

import java.util.List;

import com.dimensionrug.presupuestar.models.entities.Pegamento;

public interface IPegamentoService {
    public List<Pegamento> getPegamentos();
    
    public void savePegameto(Pegamento pegamento);

    public void deletePegamento(Integer id);

    public Pegamento findPegamento(Integer id);

    public void editPegamento(Integer id, String nombre, Double precioKilo, Double consumoM2);
}