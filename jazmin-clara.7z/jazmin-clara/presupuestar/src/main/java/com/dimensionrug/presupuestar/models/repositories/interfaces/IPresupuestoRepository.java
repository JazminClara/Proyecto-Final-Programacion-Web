package com.dimensionrug.presupuestar.models.repositories.interfaces;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dimensionrug.presupuestar.models.entities.Presupuesto;

@Repository
public interface IPresupuestoRepository extends JpaRepository<Presupuesto, Integer> {
    //Query Method para buscar por nombre exacto
    List<Presupuesto> findByNombreClienteIgnoreCase(String nombreCliente);

    //Query Method para buscar por nombre parcial
    List<Presupuesto> findByNombreClienteContaining(String nombreCliente);

    //Query Method que busca por rango de precios
    List<Presupuesto> findByPrecioTotalBetween(Double precioMinimo, Double precioMaximo);
}