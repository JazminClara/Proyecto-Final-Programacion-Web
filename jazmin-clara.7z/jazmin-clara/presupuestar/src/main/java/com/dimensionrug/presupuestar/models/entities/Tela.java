package com.dimensionrug.presupuestar.models.entities;

import com.dimensionrug.presupuestar.models.enums.Uso;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name = "telas")
public class Tela {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tela", nullable = false)
    private Integer idTela;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(name = "uso", nullable = false)
    @Enumerated(EnumType.STRING)
    private Uso uso;

    @Column(name = "ancho_fabrica", nullable = false)
    private Double anchoFabrica;

    @Column(name = "precio_metro", nullable = false)
    private Double precioMetro;

    @Column(name = "precio_m2")
    private Double precioM2;

    /* @OneToMany(mappedBy = "telaBase")
    @JsonBackReference
    private List<Presupuesto> presupuestosTelaBase;

    @OneToMany(mappedBy = "telaFondo")
    @JsonBackReference
    private List<Presupuesto> presupuestosTelaFondo; */

    /**
     * Notaciones de JPA que me permiten hacer calculo dinamico de el precio del metro cuadrado del insumo tela, cada vez que el objeto sea percistido en la base
     */
    @PrePersist
    @PreUpdate
    public void calcularPrecioM2() {
        if (anchoFabrica != null && anchoFabrica > 0) {
            this.precioM2 = precioMetro / anchoFabrica;
        } else {
            throw new IllegalArgumentException("El ancho de fabrica no puede ser 0 (cero) o menor");
        }
    }

    public Double getPrecioM2() {
        if (precioM2 == null) {
            this.calcularPrecioM2();
        }
        return precioM2;
    }
}