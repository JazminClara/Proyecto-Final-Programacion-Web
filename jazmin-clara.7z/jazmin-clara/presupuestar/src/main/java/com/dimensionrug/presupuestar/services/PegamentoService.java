package com.dimensionrug.presupuestar.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dimensionrug.presupuestar.models.entities.Pegamento;
import com.dimensionrug.presupuestar.models.repositories.interfaces.IPegamentoRepository;

@Service
public class PegamentoService implements IPegamentoService {
    @Autowired
    private IPegamentoRepository pegamentoRepository;

    @Override
    public List<Pegamento> getPegamentos() {
        List<Pegamento> listaPegamentos = pegamentoRepository.findAll();
        return listaPegamentos;
    }

    @Override
    public void savePegameto(Pegamento pegamento) {
        if (pegamento != null)
            pegamentoRepository.save(pegamento);
    }

    @Override
    public void deletePegamento(Integer id) {
        if (id != null)
            pegamentoRepository.deleteById(id);
    }

    @Override
    public Pegamento findPegamento(Integer id) {
        Pegamento pegamento = null;
        if (id != null) pegamento = pegamentoRepository.findById(id).orElse(null);
        return pegamento;
    }

    @Override
    public void editPegamento(Integer id, String nombre, Double precioKilo, Double consumoM2) {
        Pegamento pegamento = this.findPegamento(id);

        pegamento.setNombre(nombre);
        pegamento.setPrecioKilo(precioKilo);
        pegamento.setConsumoM2(consumoM2);
        
        this.savePegameto(pegamento);
    }

    
}
