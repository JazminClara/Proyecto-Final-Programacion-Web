const tablaPresupuestos = document.getElementById("tablaPresupuestos");

// Renderizar la lista de presupuestos con lo obtenido por una request
// .toFixed(2) redondea en 2 decimales
function renderizarPresupuestos(datos) {
    tablaPresupuestos.innerHTML = "";
    for (let presupuesto of datos) {
        tablaPresupuestos.innerHTML += `<tr id="presupuesto${presupuesto.idPresupuesto}"><td>${presupuesto.idPresupuesto}</td>
            <td>${presupuesto.nombreCliente}</td>
            <td>${presupuesto.anchoAlfombra} mtrs.</td>
            <td>${presupuesto.largoAlfombra} mtrs.</td>
            <td>${presupuesto.alfombraM2.toFixed(2)} m2</td>
            <td>${presupuesto.telaBase.nombre}</td>
            <td>${presupuesto.telaFondo.nombre}</td>
            <td>${presupuesto.hilado.nombre}</td>
            <td>${presupuesto.pegamento.nombre}</td>
            <td>$ ${presupuesto.precioTotal.toFixed(2)}</td>
            <td class="d-flex d-flex gap-2">
                <div type="button" class="editar button-anim" data-id="${presupuesto.idPresupuesto}" title="Editar"><img src="imagenes/Editar.webp"></div>
                <div type="button" class="eliminar button-anim" data-id="${presupuesto.idPresupuesto}" title="Eliminar"><img src="imagenes/Eliminar.webp"></div>
            </td>
            </tr>`;
    }

    //Obtengo todos los botones del DOM
    const botonesEliminar = document.querySelectorAll(".eliminar");
    //Le asigno un Listener a cada boton para abrir ventana modal
    botonesEliminar.forEach(boton => {
        boton.addEventListener("click", async () => {
            //Obtengo el id del objeto a eliminar
            idBotonBorrar = boton.dataset.id;
            let parrafoIdEliminar = document.getElementById("parrafoIdEliminar");
            parrafoIdEliminar.innerText = "Se eliminará presupuesto id: " + idBotonBorrar;
            modal.show();
        })
    })

    //Configuración de boton editar, redirecciona endpoint /presupuestos/editar
    const botonesEditar = document.querySelectorAll(".editar");

    botonesEditar.forEach(boton => {
        boton.addEventListener("click", async () => {
            let idBotonEditar = boton.dataset.id;
            window.location = `http://localhost:8080/presupuestos/editar?id=${idBotonEditar}`;
        })
    })
}


//Funcion fetch que me permite hacer consumo de API, request para obtener todos los presupuestos
function obtenerPresupuestos() {
    fetch("http://localhost:8080/presupuestos").then(response => response.json()).then(datos => renderizarPresupuestos(datos))
}
// Variable con elemento modal para eliminar presupuesto
const modal = new bootstrap.Modal(document.getElementById("modal-eliminar"));

// Variable que guarda id del presupuesto que se borrará en la ventana modal en evento botonModalEliminar.addEventListener()
let idBotonBorrar = null;

obtenerPresupuestos();

// Consumo de API (endpoint DELETE) con Axios
let botonModalEliminar = document.getElementById('eliminarPresupuesto');

botonModalEliminar.addEventListener("click", () => {
    axios.delete(`http://localhost:8080/presupuestos/${idBotonBorrar}`).then(response => {
        alert("Presupuesto eliminado");
        modal.hide();
        obtenerPresupuestos();
    }).catch(error => alert("Presupuesto no eliminado"));

});

// Búsqueda de presupuestos por nombre de cliente
let buscarNombre = document.getElementById("buscarNombre");

function buscarPorNombre() {
    // Obtengo value del input
    let nombreCliente = buscarNombre.value;
    if (nombreCliente === "") {
        obtenerPresupuestos();
        return;
    }

    buscarPrecioMin.value = "";
    buscarPrecioMax.value = "";

    // Request Axios que obtiene los presupuestos
    axios.get("http://localhost:8080/presupuestos",
        { params: { "nombreCliente": nombreCliente } }
    ).then(response => {
        let datos = response.data;
        renderizarPresupuestos(datos);
    }).catch(err => alert("Error al cargar presupuestos"))
}

buscarNombre.addEventListener("change", () => {buscarPorNombre()});

let buscarPrecioMin = document.getElementById("buscarPrecioMin");
let buscarPrecioMax = document.getElementById("buscarPrecioMax");

function buscarPorPrecioMinMax() {
    if (buscarPrecioMin.value === "" || buscarPrecioMax.value === "") {
        obtenerPresupuestos();
        return;
    }

    buscarNombre.value = "";

     // Request Axios que obtiene los presupuestos
    axios.get("http://localhost:8080/presupuestos",
        { params: {
            "precioMinimo": buscarPrecioMin.value,
            "precioMaximo": buscarPrecioMax.value
        }}
    ).then(response => {
        let datos = response.data;
        renderizarPresupuestos(datos);
    }).catch(err => alert("Error al cargar presupuestos"))
}

buscarPrecioMin.addEventListener("change", () => {buscarPorPrecioMinMax()});
buscarPrecioMax.addEventListener("change", () => {buscarPorPrecioMinMax()});
